// A tiny stand-in for the OpenAI Responses API, used by test/openai.test.js.
import http from 'node:http';

export async function startFakeOpenAI() {
  const state = { mode: 'ok', chatMode: 'ok', models: ['openrings-ai:latest', 'qwen2.5:7b'], requests: [] };
  const server = http.createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => (raw += c));
    req.on('end', () => {
      const send = (status, body, headers = {}) => {
        res.writeHead(status, { 'content-type': 'application/json', 'x-should-retry': 'false', ...headers });
        res.end(JSON.stringify(body));
      };
      if (req.method === 'GET' && req.url === '/v1/models') {
        return send(200, { object: 'list', data: state.models.map((id) => ({ id, object: 'model', created: 1700000000, owned_by: 'library' })) });
      }
      if (req.method === 'GET' && req.url.startsWith('/v1/models/')) {
        return send(200, { id: decodeURIComponent(req.url.split('/').pop()), object: 'model', created: 1700000000, owned_by: 'openai' });
      }
      const body = raw ? JSON.parse(raw) : {};
      state.requests.push({ url: req.url, body, headers: req.headers });
      if (state.mode === 'quota') {
        return send(429, { error: { message: 'You exceeded your current quota, please check your plan and billing details.', type: 'insufficient_quota', code: 'insufficient_quota', param: null } });
      }
      if (req.url === '/v1/chat/completions') {
        // Stand-in for a self-hosted, OpenAI-compatible server such as Ollama.
        if (state.chatMode === 'reject_json_schema' && body.response_format?.type === 'json_schema') {
          return send(400, { error: { message: 'response_format json_schema is not supported', type: 'invalid_request_error', code: null, param: 'response_format' } });
        }
        const sys = body.messages?.[0]?.content || '';
        const user = body.messages?.at(-1)?.content || '';
        let data;
        if (/"should_reply"/.test(sys)) data = { should_reply: true, reply_markdown: 'Self-hosted answer: create the IVR in the dialplan. (fake local model)' };
        else if (/"posts"/.test(sys)) data = { posts: [...String(user).matchAll(/<slot number="(\d+)">/g)].map((m) => ({ slot: Number(m[1]), title: `Local model question number ${m[1]} about IVR`, body: 'How do I build an IVR with office hours for 15 extensions?' })) };
        else if (/"body"/.test(sys)) data = { body: 'Thanks. Which file holds the dialplan?' };
        else data = 'OK';
        const content = typeof data === 'string' ? data : '```json\n' + JSON.stringify(data) + '\n```';
        return send(200, {
          id: 'chatcmpl-test', object: 'chat.completion', created: 1700000000, model: body.model,
          choices: [{ index: 0, message: { role: 'assistant', content }, finish_reason: 'stop' }],
          usage: { prompt_tokens: 900, completion_tokens: 120, total_tokens: 1020 },
        });
      }
      const props = body.text?.format?.schema?.properties || {};
      let data;
      if (props.should_reply) data = { should_reply: true, reply_markdown: 'Open **5060/udp** and **16384-32768/udp** on the VPS firewall. (fake OpenAI)' };
      else if (props.posts) data = { posts: [...String(body.input).matchAll(/<slot number="(\d+)">/g)].map((m) => ({ slot: Number(m[1]), title: `Fake OpenAI question number ${m[1]} about trunks`, body: 'We have 20 extensions and a SIP trunk. Inbound calls fail with 404. What should I check first?' })) };
      else if (props.body) data = { body: 'We are on 0.10.1. Which log shows the dialplan match?' };
      else data = {};
      const content = state.mode === 'refusal'
        ? [{ type: 'refusal', refusal: 'I can not help with that.' }]
        : [{ type: 'output_text', text: JSON.stringify(data), annotations: [] }];
      send(200, {
        id: 'resp_test', object: 'response', created_at: 1700000000, status: 'completed', model: body.model,
        output: [{ type: 'message', id: 'msg_test', status: 'completed', role: 'assistant', content }],
        usage: { input_tokens: 1200, input_tokens_details: { cached_tokens: 900 }, output_tokens: 150, output_tokens_details: { reasoning_tokens: 40 }, total_tokens: 1350 },
        incomplete_details: null, error: null, parallel_tool_calls: true, tools: [], tool_choice: 'auto', temperature: 1, top_p: 1,
      });
    });
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  return { state, url: `http://127.0.0.1:${server.address().port}/v1`, close: () => new Promise((r) => server.close(r)) };
}
